 /*******************************************************************************
 *  Copyright (C) 2010 Texas Instruments Incorporated - http://www.ti.com/
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 *******************************************************************************
 * Filter6_Ripple.c C Source
 * Description: This example code sets PWM Dutycycle of 50% continuosly at Timer   
 *			Outputs. Change fPWM freq in Ripple.h header file and measure ripple 
 *			amplitude seen at filter output
 * 			
 *                 MSP430F51x2
 *             -----------------
 *         /|\|              XIN|-
 *          | |                 | 32kHz
 *          --|RST          XOUT|-
 *            |                 |
 *            |       P2.3/TD1.2|--> CCR1, fPWM (Connect to Filter#6 - 2nd order
 *			  |             	|						RC Filter, 50kHz BW)
 *            |    P2.6/PM_TA0.2|--> CCR1, fPWM (Connect to Filter#6 - 2nd order
 *			  |             	|						RC Filter, 50kHz BW)
 *
 *  Note: Select either TD1.2 or TA0.2 as input signal to Filter#6. 
 *
 * MCLK = SMCLK = 16MHz DCO; ACLK = LFXT1 = 32768
 * TD1 fclock = 256Mhz hi-res clock (regulated mode)
 * TA0 fclock = 16Mhz DCO = SMCLK
 *******************************************************************************/

#include "msp430f5172.h"
#include "Ripple.h"

#define XT1_CONNECTED

void SetVcoreUp (unsigned int level);
void Port_Mapping(void);

unsigned int count;

void main(void)
{
  WDTCTL = WDTPW + WDTHOLD;                 // Stop WDT
  Port_Mapping();
  
  P1DIR |= BIT0;                            // P1.0 output

#ifdef XT1_CONNECTED
  
  // Configure XT1
  PJSEL |= BIT4+BIT5;                       // Port select XT1  
  UCSCTL6 &= ~(XT1OFF);                     // XT1 On
  UCSCTL6 |= XCAP_3;                        // Internal load cap  
  // Loop until XT1 fault flag is cleared
  do
  {
    UCSCTL7 &= ~XT1LFOFFG;                  // Clear XT1 fault flags
  }while (UCSCTL7&XT1LFOFFG);               // Test XT1 fault flag

#endif  

  // Increase Vcore setting to level3 to support fsystem=16MHz
  // NOTE: Change core voltage one level at a time..
  SetVcoreUp (0x01);
  SetVcoreUp (0x02);  
  SetVcoreUp (0x03); 
  
#ifndef XT1_CONNECTED
  UCSCTL3 = SELREF_2;                       // Set DCO FLL reference = REFO
  UCSCTL4 |= SELA_2;                        // Set ACLK = REFO
#endif

  __bis_SR_register(SCG0);                  // Disable the FLL control loop
  UCSCTL0 = 0x0000;                         // Set lowest possible DCOx, MODx
  UCSCTL1 = DCORSEL_6;                      // Select DCO range 50MHz operation
  UCSCTL2 = FLLD_1 + 487;                   // Set DCO Multiplier for 16MHz
                                            // (N + 1) * FLLRef = Fdco
                                            // (487 + 1) * 32768 = 16MHz
                                            // Set FLL Div = fDCOCLK/2
  __bic_SR_register(SCG0);                  // Enable the FLL control loop

  // Worst-case settling time for the DCO when the DCO range bits have been
  // changed is n x 32 x 32 x f_MCLK / f_FLL_reference. See UCS chapter in 5xx
  // UG for optimization.
  // 32 x 32 x 16 MHz / 32,768 Hz ~ 500k MCLK cycles for DCO to settle
  __delay_cycles(500000);

  // Loop until XT1,XT2 & DCO stabilizes - In this case only DCO has to stabilize
  do
  {
    UCSCTL7 &= ~(XT1LFOFFG + XT1HFOFFG + DCOFFG);
                                            // Clear XT2,XT1,DCO fault flags
    SFRIFG1 &= ~OFIFG;                      // Clear fault flags
  }while (SFRIFG1&OFIFG);                   // Test oscillator fault flag  
                                        
  // Configure TA0 in normal mode
  TA0CCTL0 = OUTMOD_4;                      // CCR0 toggle (PWM period/2)
  TA0CCR0 = PWM_DUTYCYCLE_RESOLUTION_NORMAL-1;  // PWM period with #dutycycle counts
  TA0CTL = TDSSEL_2;                        // SMCLK, clear TDR  
  TA0CCTL2 = OUTMOD_7;                      // CCR1 reset/set
  TA0CCR2 = PWM_DUTYCYCLE_RESOLUTION_NORMAL>>1; // TA0.1 Initial PWM duty cycle    
  
  // Configure TD0 in Hi-Res Calibrated Mode
  TD1CTL0 = TDSSEL_2;                       // TDCLK=SMCLK=16MHz=Hi-Res input clk select  
  TD1CTL1 |= TDCLKM_1;                      // Select Hi-res local clock
  TD1HCTL0 = TDHM_1 + TDHCALEN + TDHEN;     // Hi-res clock 16x TDCLK, 
                                            // Calibration and Hi-res mode enable
  TD1HINT |= TDHLKIE;                       // Enable TDH Lock IFG  
  
  // Start timer when Hi-Res freq locked
  // Configure TD0 CCRx blocks
  TD1CCTL0 = OUTMOD_4;                      // CCR0 toggle (PWM period/2)
  TD1CCR0 = PWM_DUTYCYCLE_RESOLUTION-1;     // PWM Period
  TD1CCTL2 = OUTMOD_7;                      // CCR2 reset/set
  TD1CCR2 = PWM_DUTYCYCLE_RESOLUTION>>1;    // TD1.1 PWM duty cycle = 50%
  
  // Start Timers
  TD1CTL0 |= MC_1 + TDCLR;                  // up-mode, clear TDR, Start timer
  TA0CTL |= MC_1 + TACLR;                   // up-mode, clear TDR, Start timer
  
  __bis_SR_register(LPM0_bits + GIE);       // Enter LPM0
  __no_operation();                         // For debugger  
}
  
// Timer1_D1 Interrupt Vector (TDIV) handler
#pragma vector=TIMER1_D1_VECTOR
__interrupt void TIMER1_D1_ISR(void)
{
  switch(__even_in_range(TD1IV,30))
  {
    case  0: break;                          // No interrupt
    case  2: break;                          // CCR1 not used
    case  4: break;                          // CCR2 not used
    case  6: break;                          // reserved
    case  8: break;                          // reserved
    case 10: break;                          // reserved
    case 12: break;                          // reserved
    case 14: break;
    case 16: break;
    case 18:                                 // Clock fail low
      while(1);                              // Input ref clock freq too low; trap here                          
    case 20:                                 // Clock fail high
      while(1);                              // Input ref clock freq too high; trap here                          
    case 22:                                 // Hi-res freq locked
      // Hi-Res freq locked; now configure ports to output PWMs
      P2SEL |= BIT3;                         // P2.3/TD1.2 option select
      P2DIR |= BIT3;                  
      P2SEL |= BIT6;                         // P2.6/TA0.2
      P2DIR |= BIT6;        
      break;
    case 24: break;                          // Hi-res freq unlocked
    case 26: break;                          // reserved
    case 28: break;                          // reserved
    case 30: break;                          // reserved       
    default: break; 
  }   
}

  
void SetVcoreUp (unsigned int level)
{
  // Open PMM registers for write
  PMMCTL0_H = PMMPW_H;              
  // Set SVS/SVM high side new level
  SVSMHCTL = SVSHE + SVSHRVL0 * level + SVMHE + SVSMHRRL0 * level;
  // Set SVM low side to new level
  SVSMLCTL = SVSLE + SVMLE + SVSMLRRL0 * level;
  // Wait till SVM is settled
  while ((PMMIFG & SVSMLDLYIFG) == 0);
  // Clear already set flags
  PMMIFG &= ~(SVMLVLRIFG + SVMLIFG);
  // Set VCore to new level
  PMMCTL0_L = PMMCOREV0 * level;
  // Wait till new level reached
  if ((PMMIFG & SVMLIFG))
    while ((PMMIFG & SVMLVLRIFG) == 0);
  // Set SVS/SVM low side to new level
  SVSMLCTL = SVSLE + SVSLRVL0 * level + SVMLE + SVSMLRRL0 * level;
  // Lock PMM registers for write access
  PMMCTL0_H = 0x00;
}

void Port_Mapping(void)
{
  __disable_interrupt();                    // Disable Interrupts before altering Port Mapping registers
  PMAPPWD = 0x02D52;                        // Enable Write-access to modify port mapping registers
  
  #ifdef PORT_MAP_RECFG                     
  PMAPCTL = PMAPRECFG;                      // Allow reconfiguration during runtime
  #endif  
  
  P2MAP6 = PM_TA0_2;
  
  PMAPPWD = 0;                              // Disable Write-Access to modify port mapping registers
  #ifdef PORT_MAP_EINT
  __enable_interrupt();                     // Re-enable all interrupts
  #endif  
}



