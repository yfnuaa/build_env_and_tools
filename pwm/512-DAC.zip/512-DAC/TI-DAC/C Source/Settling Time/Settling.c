 /*******************************************************************************
 *  Copyright (C) 2010 Texas Instruments Incorporated - http://www.ti.com/
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *    Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 *    Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the
 *    distribution.
 *
 *    Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR
 *  A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT
 *  OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL,
 *  SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT
 *  LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE,
 *  DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY
 *  THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
 *  (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE
 *  OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 *
 ******************************************************************************
 * Description: This example code increases PWM Dutycycle from 0 to 100% at once 
 *				and then decreases dutycycle from 100% to 0% and this reapeats
 *				at a rate of Fupdate = 8kHz
 * 			
 *                 MSP430F51x2
 *             -----------------
 *         /|\|              XIN|-
 *          | |                 | 32kHz
 *          --|RST          XOUT|-
 *            |                 |
 *            |       P2.2/TD1.1|--> CCR1, 500kHz (Connect to Filter#4 - 2nd order
 *			  |             	|						RC Filter, 20kHz BW)
 *            |       			|
 *
 * MCLK = SMCLK = 16MHz DCO; ACLK = LFXT1 = 32768
 * TD1 fclock = 256Mhz hi-res clock (regulated mode)
 * TD1.1 PWM Frequency = 500kHz
 * TD1.1 PWM dutycycle resolution = 512
 * Fupdate timer = TimerA0 (8kHz interrupts)
 *******************************************************************************/

#include "msp430f5172.h"
#include "Settling.h"

#define XT1_CONNECTED

void SetVcoreUp (unsigned int level);

unsigned char toggle = 0;

void main(void)
{
  WDTCTL = WDTPW + WDTHOLD;                 // Stop WDT
  
  P1DIR |= BIT0;                            // P1.0 output
  P1OUT |= BIT0;

#ifdef XT1_CONNECTED
  
  // Configure XT1
  PJSEL |= BIT4+BIT5;                       // Port select XT1  
  UCSCTL6 &= ~(XT1OFF);                     // XT1 On
  UCSCTL6 |= XCAP_3;                        // Internal load cap  
  // Loop until XT1 fault flag is cleared
  do
  {
    UCSCTL7 &= ~XT1LFOFFG;                  // Clear XT1 fault flags
  }while (UCSCTL7&XT1LFOFFG);               // Test XT1 fault flag

#endif  

  // Increase Vcore setting to level3 to support fsystem=16MHz
  // NOTE: Change core voltage one level at a time..
  SetVcoreUp (0x01);
  SetVcoreUp (0x02);  
  SetVcoreUp (0x03); 
  
#ifndef XT1_CONNECTED
  UCSCTL3 = SELREF_2;                       // Set DCO FLL reference = REFO
  UCSCTL4 |= SELA_2;                        // Set ACLK = REFO
#endif

  __bis_SR_register(SCG0);                  // Disable the FLL control loop
  UCSCTL0 = 0x0000;                         // Set lowest possible DCOx, MODx
  UCSCTL1 = DCORSEL_6;                      // Select DCO range 50MHz operation
  UCSCTL2 = FLLD_1 + 487;                   // Set DCO Multiplier for 16MHz
                                            // (N + 1) * FLLRef = Fdco
                                            // (487 + 1) * 32768 = 16MHz
                                            // Set FLL Div = fDCOCLK/2
  __bic_SR_register(SCG0);                  // Enable the FLL control loop

  // Worst-case settling time for the DCO when the DCO range bits have been
  // changed is n x 32 x 32 x f_MCLK / f_FLL_reference. See UCS chapter in 5xx
  // UG for optimization.
  // 32 x 32 x 16 MHz / 32,768 Hz ~ 500k MCLK cycles for DCO to settle
  __delay_cycles(500000);

  // Loop until XT1,XT2 & DCO stabilizes - In this case only DCO has to stabilize
  do
  {
    UCSCTL7 &= ~(XT1LFOFFG + XT1HFOFFG + DCOFFG);
                                            // Clear XT2,XT1,DCO fault flags
    SFRIFG1 &= ~OFIFG;                      // Clear fault flags
  }while (SFRIFG1&OFIFG);                   // Test oscillator fault flag
  
  // Configure TA0 for 8kHz interrupts
  TA0CCR0 = fUPDATE_COUNT;                  // Update interrupts
  TA0CTL = TASSEL_2 + TACLR;                // SMCLK, clear TAR  
                                            // Start timer when Hi-Res freq locked
  
  // Configure TimerD1 in Hi-Res Calibrated Mode
  TD1CTL0 = TDSSEL_2;                       // TDCLK=SMCLK=16MHz=Hi-Res input clk select  
  TD1CTL1 |= TDCLKM_1;                      // Select Hi-res local clock
  TD1HCTL0 = TDHM_1 + TDHCALEN + TDHEN;     // Hi-res clock 16x TDCLK, 
                                            // Calibration and Hi-res mode enable
  TD1HINT |= TDHLKIE;                       // Enable TDH Lock IFG  
  
  // Configure TD1 CCRx blocks
  TD1CCTL0 = OUTMOD_4;                      // CCR0 toggle (PWM period/2)
  TD1CCR0 = PWM_DUTYCYCLE_RESOLUTION-1;     // PWM Period
  TD1CCTL1 = OUTMOD_7;                      // CCR1 reset/set
  TD1CCR1 = 0;                              // CCR1 Initial PWM duty cycle
  TD1CTL0 |= MC_1 + TDCLR;                  // up-mode, clear TDR, Start timer
  
  __bis_SR_register(LPM0_bits + GIE);       // Enter LPM0
  __no_operation();                         // For debugger  
}
  
// Timer1_D1 Interrupt Vector (TDIV) handler
#pragma vector=TIMER1_D1_VECTOR
__interrupt void TIMER1_D1_ISR(void)
{
  switch(__even_in_range(TD1IV,30))
  {
    case  0: break;                          // No interrupt
    case  2: break;                          // CCR1 not used
    case  4: break;                          // CCR2 not used
    case  6: break;                          // reserved
    case  8: break;                          // reserved
    case 10: break;                          // reserved
    case 12: break;                          // reserved
    case 14: break;
    case 16: break;
    case 18:                                 // Clock fail low
      while(1);                              // Input ref clock freq too low; trap here                          
    case 20:                                 // Clock fail high
      while(1);                              // Input ref clock freq too high; trap here                          
    case 22:                                 // Hi-res freq locked
      // Hi-Res freq locked; now configure ports to output PWMs at TD1.0/1/2
      P2SEL |= BIT2 + BIT3;                  // P2.2,3 option select
      P2DIR |= BIT2 + BIT3;                  // P2.2,3 output
      TA0CCTL0 = CCIE;                       // CCR0 interrupt enabled
      TA0CTL |= MC_1;                        // Start TA0 in up mode
      break;
    case 24: break;                          // Hi-res freq unlocked
    case 26: break;                          // reserved
    case 28: break;                          // reserved
    case 30: break;                          // reserved       
    default: break; 
  }   
}
 
// Timer0 A0 interrupt service routine
#pragma vector=TIMER0_A0_VECTOR
__interrupt void TIMER0_A0_ISR(void)
{
  if (toggle)
  {
    TD1CCR1 = PWM_DUTYCYCLE_RESOLUTION-16;  // TD1.1 = max value
    toggle = 0;
  }
  else
  {
    TD1CCR1 = 0x0;                          // TD1.1 = 0
    toggle = 0x01;  
  }
  
  P1OUT ^= BIT0;                            // Toggle P1.0
}

void SetVcoreUp (unsigned int level)
{
  // Open PMM registers for write
  PMMCTL0_H = PMMPW_H;              
  // Set SVS/SVM high side new level
  SVSMHCTL = SVSHE + SVSHRVL0 * level + SVMHE + SVSMHRRL0 * level;
  // Set SVM low side to new level
  SVSMLCTL = SVSLE + SVMLE + SVSMLRRL0 * level;
  // Wait till SVM is settled
  while ((PMMIFG & SVSMLDLYIFG) == 0);
  // Clear already set flags
  PMMIFG &= ~(SVMLVLRIFG + SVMLIFG);
  // Set VCore to new level
  PMMCTL0_L = PMMCOREV0 * level;
  // Wait till new level reached
  if ((PMMIFG & SVMLIFG))
    while ((PMMIFG & SVMLVLRIFG) == 0);
  // Set SVS/SVM low side to new level
  SVSMLCTL = SVSLE + SVSLRVL0 * level + SVMLE + SVSMLRRL0 * level;
  // Lock PMM registers for write access
  PMMCTL0_H = 0x00;
}

